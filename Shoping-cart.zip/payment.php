<?php

include 'config.php';
session_start();

if(!isset($_SESSION['user_id'])) {
    header('location:login.php');
    exit(); 
}

if(isset($_POST['submit_payment'])) {

    $user_id = $_SESSION['user_id'];
    $card_number = $_POST['card_number'];
    $expiry_date = $_POST['expiry_date'];
    $cvv = $_POST['cvv'];


    $insert_payment = mysqli_query($conn, "INSERT INTO `payments` (user_id, card_number, expiry_date, cvv) VALUES ('$user_id', '$card_number', '$expiry_date', '$cvv')");

    if($insert_payment) {
    
        header('location:invoice.php');
        exit(); 
        echo '<div class="message">Failed to store payment details. Please try again.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Payment Details</title>
   <!-- Custom CSS file link -->
   <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
   <h1 class="heading">Payment Details</h1>
   
   <form method="post" action="">
      <label for="card_number">Card Number:</label>
      <input type="text" id="card_number" name="card_number" required>

      <label for="expiry_date">Expiry Date:</label>
      <input type="text" id="expiry_date" name="expiry_date" placeholder="MM/YYYY" required>

      <label for="cvv">CVV:</label>
      <input type="text" id="cvv" name="cvv" required>

      <input type="submit" name="submit_payment" value="Submit Payment" class="btn">
   </form>

</div>

</body>
</html>
