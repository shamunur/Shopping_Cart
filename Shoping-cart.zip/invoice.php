<?php
include 'config.php';
session_start();

if(!isset($_SESSION['user_id'])) {
    header('location:login.php');
    exit(); // Stop further execution
}

$user_id = $_SESSION['user_id'];
$select_payment = mysqli_query($conn, "SELECT * FROM `payments` WHERE user_id = '$user_id' ORDER BY id DESC LIMIT 1");

if(mysqli_num_rows($select_payment) > 0) {
    $payment_details = mysqli_fetch_assoc($select_payment);
} else {
 
    echo '<div class="message">No payment details found.</div>';
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Invoice</title>

   <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
   <h1 class="heading">Invoice</h1>
   
   <div class="invoice-details">
      <p><strong>User ID:</strong> <?php echo $user_id; ?></p>
      <p><strong>Card Number:</strong> <?php echo $payment_details['card_number']; ?></p>
      <p><strong>Expiry Date:</strong> <?php echo $payment_details['expiry_date']; ?></p>
      <p><strong>CVV:</strong> <?php echo $payment_details['cvv']; ?></p>
   </div>

   <button onclick="window.print()" class="btn">Print Invoice</button>
</div>

</body>
</html>
